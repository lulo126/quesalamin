import ProductCard from "./ProductCard";

const salamines = [
  {
    name: "Salame con piel",
    price: "$14.000",
    image: "https://res.cloudinary.com/divsvn2yk/image/upload/v1773592686/WhatsApp_Image_2026-03-15_at_1.22.12_PM_wdmcbq.jpg",
  },
  {
    name: "Salame al vacío",
    price: "$14.000",
    image: "https://res.cloudinary.com/divsvn2yk/image/upload/v1773592688/WhatsApp_Image_2026-03-15_at_1.22.12_PM_1_kfdjbb.jpg",
  },
];

const quesos = [
  {
    name: "Queso de Orégano",
    price: "$7.500",
    image: "https://res.cloudinary.com/divsvn2yk/image/upload/v1773592694/WhatsApp_Image_2026-03-15_at_1.22.12_PM_2_y2uwb6.jpg",
  },
  {
    name: "Queso de Pimienta",
    price: "$7.500",
    image: "https://res.cloudinary.com/divsvn2yk/image/upload/v1773592703/WhatsApp_Image_2026-03-15_at_1.22.13_PM_br2tfe.jpg",
  },
  {
    name: "Queso Mixto",
    price: "$7.500",
    image: "https://res.cloudinary.com/divsvn2yk/image/upload/v1773592713/WhatsApp_Image_2026-03-15_at_1.22.13_PM_1_lyy4r1.jpg",
  },
  {
    name: "Queso de Ají",
    price: "$7.500",
    image: "https://res.cloudinary.com/divsvn2yk/image/upload/v1773592716/WhatsApp_Image_2026-03-15_at_1.22.13_PM_2_odtxiq.jpg",
  },
];

const ProductGrid = () => {
  return (
    <section id="productos" className="py-20 md:py-28">
      <div className="container">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-center text-foreground mb-4">
          Nuestros Productos
        </h2>
        <p className="text-muted-foreground text-center mb-12 max-w-lg mx-auto">
          Elaborados artesanalmente con los mejores ingredientes
        </p>

        {/* Salamines */}
        <h3 className="font-display text-2xl font-semibold text-foreground mb-6 flex items-center gap-2">
          🥩 Salamines
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-14">
          {salamines.map((p) => (
            <ProductCard key={p.name} {...p} />
          ))}
        </div>

        {/* Quesos */}
        <h3 className="font-display text-2xl font-semibold text-foreground mb-6 flex items-center gap-2">
          🧀 Quesos <span className="text-base font-body font-normal text-muted-foreground">(por 1/4)</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {quesos.map((p) => (
            <ProductCard key={p.name} {...p} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductGrid;
