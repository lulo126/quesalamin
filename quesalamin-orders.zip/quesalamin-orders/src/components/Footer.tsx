import { Instagram, MapPin, MessageCircle } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          <div>
            <h4 className="font-display text-xl font-bold mb-3">Quesalamin</h4>
            <p className="text-primary-foreground/70 text-sm">
              Quesos y salamines artesanales de excelente calidad.
            </p>
          </div>

          <div>
            <h4 className="font-display text-lg font-semibold mb-3">Contacto</h4>
            <div className="space-y-2 text-sm text-primary-foreground/70">
              <a
                href="https://wa.me/543812115390"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center md:justify-start gap-2 hover:text-primary-foreground transition-colors"
              >
                <MessageCircle size={16} />
                381 211 5390
              </a>
              <a
                href="https://instagram.com/quesalamin_"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center md:justify-start gap-2 hover:text-primary-foreground transition-colors"
              >
                <Instagram size={16} />
                @quesalamin_
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-display text-lg font-semibold mb-3">Ubicación</h4>
            <p className="flex items-center justify-center md:justify-start gap-2 text-sm text-primary-foreground/70">
              <MapPin size={16} />
              Country Vilanova – Lote 15
            </p>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-10 pt-6 text-center text-sm text-primary-foreground/50">
          © {new Date().getFullYear()} Quesalamin. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
