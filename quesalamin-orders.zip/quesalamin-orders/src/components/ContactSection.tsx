import { MessageCircle, Instagram, User } from "lucide-react";
import { Button } from "@/components/ui/button";

const ContactSection = () => {
  return (
    <section id="contacto" className="py-20 md:py-28">
      <div className="container max-w-2xl text-center">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-12">
          Contacto
        </h2>

        <div className="bg-card rounded-lg p-8 md:p-12 shadow-md space-y-6">
          <div className="flex items-center justify-center gap-3 text-foreground">
            <User size={20} className="text-accent" />
            <span className="font-medium">Simón Fernández</span>
          </div>

          <div className="flex items-center justify-center gap-3">
            <MessageCircle size={20} className="text-accent" />
            <a
              href="https://wa.me/543812115390"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-foreground hover:text-accent transition-colors"
            >
              381 211 5390
            </a>
          </div>

          <div className="flex items-center justify-center gap-3">
            <Instagram size={20} className="text-accent" />
            <a
              href="https://instagram.com/quesalamin_"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-foreground hover:text-accent transition-colors"
            >
              @quesalamin_
            </a>
          </div>

          <div className="pt-4">
            <a
              href="https://wa.me/543812115390?text=Hola,%20quiero%20hacer%20una%20consulta"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button variant="whatsapp" size="lg" className="gap-2 px-8">
                <MessageCircle size={20} />
                Enviar mensaje
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
