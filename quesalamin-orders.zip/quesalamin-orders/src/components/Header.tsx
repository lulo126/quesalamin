import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const navLinks = [
  { label: "Inicio", href: "#inicio" },
  { label: "Productos", href: "#productos" },
  { label: "Envíos", href: "#envios" },
  { label: "Contacto", href: "#contacto" },
];

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-card/95 backdrop-blur-md shadow-md" : "bg-transparent"
      }`}
    >
      <div className="container flex items-center justify-between h-16 md:h-20">
        <a href="#inicio" className="font-display text-2xl font-bold text-primary">
          Quesalamin
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium text-foreground/80 hover:text-accent transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a href="https://wa.me/543812115390?text=Hola,%20quiero%20hacer%20un%20pedido" target="_blank" rel="noopener noreferrer">
            <Button variant="whatsapp" size="sm">Pedir por WhatsApp</Button>
          </a>
        </nav>

        {/* Mobile toggle */}
        <button className="md:hidden text-foreground" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menú">
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <nav className="md:hidden bg-card border-t border-border px-6 pb-6 pt-2 space-y-4 animate-fade-in-up">
          {navLinks.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setMenuOpen(false)}
              className="block text-sm font-medium text-foreground/80 hover:text-accent transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a href="https://wa.me/543812115390?text=Hola,%20quiero%20hacer%20un%20pedido" target="_blank" rel="noopener noreferrer" className="block">
            <Button variant="whatsapp" className="w-full">Pedir por WhatsApp</Button>
          </a>
        </nav>
      )}
    </header>
  );
};

export default Header;
