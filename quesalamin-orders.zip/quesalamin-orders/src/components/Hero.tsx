import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center justify-center"
    >
      <div className="absolute inset-0">
        <img
          src="https://res.cloudinary.com/divsvn2yk/image/upload/v1773592677/WhatsApp_Image_2026-03-15_at_1.22.11_PM_wtbwca.jpg"
          alt="Quesos y salamines artesanales Quesalamin"
          className="w-full h-full object-cover"
          loading="eager"
        />
        <div className="absolute inset-0 bg-cocoa/60" />
      </div>

      <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
        <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-card mb-6 leading-tight">
          Quesos y Salamines Artesanales
        </h1>
        <p className="text-card/85 text-lg md:text-xl mb-10 font-light max-w-xl mx-auto leading-relaxed">
          Productos artesanales de excelente calidad, elaborados con dedicación.
          Envíos sin cargo en Yerba Buena.
        </p>
        <a
          href="#productos"
        >
          <Button variant="hero" size="lg" className="px-10 py-6 text-lg">
            Hacer Pedido
          </Button>
        </a>
      </div>
    </section>
  );
};

export default Hero;
