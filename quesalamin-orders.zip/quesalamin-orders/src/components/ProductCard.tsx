import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";

interface ProductCardProps {
  name: string;
  price: string;
  image: string;
}

const ProductCard = ({ name, price, image }: ProductCardProps) => {
  const waMessage = encodeURIComponent(`Hola, quiero consultar por ${name}`);
  const waUrl = `https://wa.me/543812115390?text=${waMessage}`;

  return (
    <div className="group bg-card rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <div className="aspect-square overflow-hidden">
        <img
          src={image}
          alt={name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </div>
      <div className="p-5">
        <h3 className="font-display text-lg font-semibold text-foreground mb-1">
          {name}
        </h3>
        <p className="text-accent font-bold text-xl mb-4">{price}</p>
        <a href={waUrl} target="_blank" rel="noopener noreferrer" className="block">
          <Button variant="whatsapp" className="w-full gap-2">
            <MessageCircle size={18} />
            Pedir por WhatsApp
          </Button>
        </a>
      </div>
    </div>
  );
};

export default ProductCard;
