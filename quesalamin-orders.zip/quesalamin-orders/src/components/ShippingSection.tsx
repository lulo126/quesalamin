import { Truck, MapPin } from "lucide-react";

const ShippingSection = () => {
  return (
    <section id="envios" className="py-20 md:py-28 bg-muted">
      <div className="container">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-center text-foreground mb-12">
          Envíos y Retiro
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {/* Envío */}
          <div className="bg-card rounded-lg p-8 shadow-md text-center">
            <Truck className="mx-auto mb-4 text-accent" size={40} />
            <h3 className="font-display text-xl font-semibold text-foreground mb-4">
              Envío
            </h3>
            <p className="text-foreground font-medium">
              Yerba Buena: <span className="text-accent font-bold">SIN CARGO</span>
            </p>
            <p className="text-muted-foreground mt-2 text-sm">
              Otras zonas: consultar
            </p>
          </div>

          {/* Retiro */}
          <div className="bg-card rounded-lg p-8 shadow-md text-center">
            <MapPin className="mx-auto mb-4 text-accent" size={40} />
            <h3 className="font-display text-xl font-semibold text-foreground mb-4">
              Retiro en persona
            </h3>
            <p className="text-foreground font-medium">
              Country Vilanova
            </p>
            <p className="text-muted-foreground mt-1 text-sm">
              Lote 15
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ShippingSection;
